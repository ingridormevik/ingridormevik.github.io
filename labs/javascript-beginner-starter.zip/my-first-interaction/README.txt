Open this folder in VS Code. Follow the JavaScript first steps guide. The empty story.js is intentional.
Save both files and use Microsoft Live Preview.
The solution folder is a separate completed reference.
